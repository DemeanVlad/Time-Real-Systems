public class Resursa {
    int res;

    synchronized int getRes(int res) throws InterruptedException {
        wait(100,20);

        return res;

    }

    synchronized void setRes(int res) throws InterruptedException {
        notify();
        wait();
        this.res = res;
    }

}
