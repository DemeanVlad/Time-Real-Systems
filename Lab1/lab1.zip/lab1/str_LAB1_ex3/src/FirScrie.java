public class FirScrie extends Thread{
    Resursa res;
    FirScrie(Resursa res){
    this.res=res;

    }

   @Override
    public void run() {
       for (int i = 1; i <= 10; i++) {
           try {
               res.setRes(i);
           } catch (InterruptedException e) {
               throw new RuntimeException(e);
           }
           System.out.println("Am scris:" + i);
       }
   }
   }
