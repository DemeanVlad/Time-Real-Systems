public class Main {
    public static void main(String[] args) {
        Resursa res= new Resursa();
        FirScrie fs=new FirScrie(res);
        FirCiteste fc=new FirCiteste(res);
        fs.start();
        fc.start();
    }
}

