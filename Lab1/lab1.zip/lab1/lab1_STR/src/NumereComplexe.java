public class NumereComplexe {
    private double parteReala;
    private double parteImaginara;

    public NumereComplexe(double parteReala, double parteImaginara) {
        this.parteReala = parteReala;
        this.parteImaginara = parteImaginara;
    }

    public double getParteReala() {
        return parteReala;
    }

    public double getParteImaginara() {
        return parteImaginara;
    }


    public NumereComplexe suma (NumereComplexe other){
        double rezultatReal= this.parteReala + other.parteReala;
        double rezultatImaginar= this.parteImaginara + other.parteImaginara;
        return new NumereComplexe(rezultatReal, rezultatImaginar);
    }

    public NumereComplexe produs (NumereComplexe other){
        double rezR= this.parteReala * other.parteReala - this.parteImaginara * other.parteImaginara;
        double rezIm= this.parteReala * other.parteImaginara + this.parteImaginara * other.parteReala;
        return new NumereComplexe(rezR , rezIm);
    }

    public void display() {
        if (parteImaginara < 0) {
            System.out.println(parteReala + " - " + Math.abs(parteImaginara) + "i");
        } else {
            System.out.println(parteReala + " + " + parteImaginara + "i");
        }
    }
}
