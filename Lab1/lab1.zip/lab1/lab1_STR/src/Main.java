public class Main {
    public static void main(String[] args) {
        NumereComplexe complex1 = new NumereComplexe(2, 5);
        NumereComplexe complex2 = new NumereComplexe(4, -1);


        NumereComplexe sum = complex1.suma(complex2);
        NumereComplexe product = complex1.produs(complex2);

        System.out.println("Suma: ");
        sum.display();
        System.out.println("Produsul: ");
        product.display();

    }
}