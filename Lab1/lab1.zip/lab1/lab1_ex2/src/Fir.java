 class Fir implements Runnable {
    int pas;
    int suma;

     public Fir(int pas) {
         this.pas = pas;
         this.suma=0;
     }

     public int getSuma() {
         return suma;
     }

     public void run() {
            for (int i = 0; i <= 40; i += pas) {
                suma += i;
            }

         System.out.println("Suma pentru pasul " + pas + ": " + suma);
        }
    }

